# Compatibility with old Defense API code
from cbapi.psc.defense import *
